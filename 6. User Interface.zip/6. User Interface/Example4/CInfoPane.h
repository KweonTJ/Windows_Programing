﻿#pragma once
#include "CInfoCtrl.h"


// CInfoPane

class CInfoPane : public CDockablePane
{
	DECLARE_DYNAMIC(CInfoPane)

public:
	CInfoPane();
	virtual ~CInfoPane();

protected:
	DECLARE_MESSAGE_MAP()
public:
	CInfoCtrl m_ctrlInfo;
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
};


