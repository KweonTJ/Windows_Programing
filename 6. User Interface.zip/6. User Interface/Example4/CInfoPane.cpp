﻿// CInfoPane.cpp: 구현 파일
//

#include "pch.h"
#include "Example4.h"
#include "CInfoPane.h"


// CInfoPane

IMPLEMENT_DYNAMIC(CInfoPane, CDockablePane)

CInfoPane::CInfoPane()
{

}

CInfoPane::~CInfoPane()
{
}


BEGIN_MESSAGE_MAP(CInfoPane, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
END_MESSAGE_MAP()



// CInfoPane 메시지 처리기



int CInfoPane::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  여기에 특수화된 작성 코드를 추가합니다.
	if (!m_ctrlInfo.Create(IDD_DIALOG_INFO, this))
	{
		TRACE0("개인 정보 윈도우를 만들지 못했습니다.\n");
		return -1;
	}
	m_ctrlInfo.ShowWindow(SW_SHOW);
	return 0;
}

void CInfoPane::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);

	// TODO: 여기에 메시지 처리기 코드를 추가합니다.
	if (m_ctrlInfo.GetSafeHwnd())
	{
		m_ctrlInfo.MoveWindow(0, 0, cx, cy);
		m_ctrlInfo.SetFocus();
	}
}
