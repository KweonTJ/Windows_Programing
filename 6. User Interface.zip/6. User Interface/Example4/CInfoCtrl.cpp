﻿// CInfoCtrl.cpp: 구현 파일
//

#include "pch.h"
#include "Example4.h"
#include "afxdialogex.h"
#include "CInfoCtrl.h"

#include "MainFrm.h"
#include "Example4Doc.h"
#include "Example4View.h"
// CInfoCtrl 대화 상자

IMPLEMENT_DYNAMIC(CInfoCtrl, CDialogEx)

CInfoCtrl::CInfoCtrl(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG_INFO, pParent)
	, m_strName(_T(""))
{
	m_bSex = true;
	m_bChecked[0] = m_bChecked[1] = m_bChecked[2] = false;
}

CInfoCtrl::~CInfoCtrl()
{
}

void CInfoCtrl::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_NAME, m_strName);
	DDX_Control(pDX, IDC_COMBO_GENDER, m_cbSex);
	DDX_Control(pDX, IDC_LIST_HOBBY, m_listHobby);
}


BEGIN_MESSAGE_MAP(CInfoCtrl, CDialogEx)
	ON_CBN_SELCHANGE(IDC_COMBO_SEX, &CInfoCtrl::OnSelchangeComboSex)
	ON_COMMAND(IDC_RADIO_MALE, &CInfoCtrl::OnRadioMale)
	ON_COMMAND(IDC_RADIO_FEMALE, &CInfoCtrl::OnRadioFemale)
	ON_LBN_SELCHANGE(IDC_LIST_HOBBY, &CInfoCtrl::OnSelchangeListHobby)
	ON_BN_CLICKED(IDC_CHECK_READING, &CInfoCtrl::OnClickedCheckReading)
	ON_BN_CLICKED(IDC_CHECK_FISHING, &CInfoCtrl::OnClickedCheckFishing)
	ON_BN_CLICKED(IDC_CHECK_SPORTS, &CInfoCtrl::OnClickedCheckSports)
	ON_BN_CLICKED(IDC_BUTTON_RESULT, &CInfoCtrl::OnClickedButtonResult)
END_MESSAGE_MAP()


// CInfoCtrl 메시지 처리기

BOOL CInfoCtrl::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  여기에 추가 초기화 작업을 추가합니다.
	m_listHobby.AddString(_T("독 서"));
	m_listHobby.AddString(_T("낚 시"));
	m_listHobby.AddString(_T("운 동"));

	m_cbSex.SetCurSel(0);

	((CButton*)GetDlgItem(IDC_RADIO_MALE))->SetCheck(TRUE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// 예외: OCX 속성 페이지는 FALSE를 반환해야 합니다.
}

void CInfoCtrl::OnSelchangeComboSex()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	int index = m_cbSex.GetCurSel();
	switch (index)
	{
	case 0:
		m_bSex = true;
		((CButton*)GetDlgItem(IDC_RADIO_MALE))->SetCheck(TRUE);
		((CButton*)GetDlgItem(IDC_RADIO_FEMALE))->SetCheck(FALSE);
		break;
	case 1:
		m_bSex = false;
		((CButton*)GetDlgItem(IDC_RADIO_MALE))->SetCheck(FALSE);
		((CButton*)GetDlgItem(IDC_RADIO_FEMALE))->SetCheck(TRUE);
		break;
	}
}

void CInfoCtrl::OnRadioMale()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	m_bSex = true;
	m_cbSex.SetCurSel(0);
}

void CInfoCtrl::OnRadioFemale()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	m_bSex = false;
	m_cbSex.SetCurSel(1);
}

void CInfoCtrl::OnSelchangeListHobby()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	int index = m_listHobby.GetCurSel();
	switch (index)
	{
	case 0:
		if (!m_bChecked[0])
			((CButton*)GetDlgItem(IDC_CHECK_READING))->SetCheck(TRUE);
		else
			((CButton*)GetDlgItem(IDC_CHECK_READING))->SetCheck(FALSE);
		m_bChecked[0] = !m_bChecked[0];
		break;
	case 1:
		if (!m_bChecked[1])
			((CButton*)GetDlgItem(IDC_CHECK_FISHING))->SetCheck(TRUE);
		else
			((CButton*)GetDlgItem(IDC_CHECK_FISHING))->SetCheck(FALSE);
		m_bChecked[1] = !m_bChecked[1];
		break;
	case 2:
		if (!m_bChecked[2])
			((CButton*)GetDlgItem(IDC_CHECK_SPORTS))->SetCheck(TRUE);
		else
			((CButton*)GetDlgItem(IDC_CHECK_SPORTS))->SetCheck(FALSE);
		m_bChecked[2] = !m_bChecked[2];
		break;
	}
}

void CInfoCtrl::OnClickedCheckReading()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	if (m_bChecked[0] == false)
		m_listHobby.SetSel(0, 1);
	else
		m_listHobby.SetSel(0, 0);
	m_bChecked[0] = !m_bChecked[0];
}

void CInfoCtrl::OnClickedCheckFishing()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	if (m_bChecked[1] == false)
		m_listHobby.SetSel(1, 1);
	else
		m_listHobby.SetSel(1, 0);
	m_bChecked[1] = !m_bChecked[1];
}

void CInfoCtrl::OnClickedCheckSports()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	if (m_bChecked[2] == false)
		m_listHobby.SetSel(2, 1);
	else
		m_listHobby.SetSel(2, 0);
	m_bChecked[2] = !m_bChecked[2];
}

void CInfoCtrl::OnClickedButtonResult()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CExample4View* pView = (CExample4View*)pFrame->GetActiveView();
	UpdateData(TRUE);
	pView->m_strName = _T("이름 : ");
	pView->m_strName += m_strName;

	pView->m_strSex = _T("성별 : ");
	if (m_bSex)
	{
		pView->m_strSex += _T("남자");
	}
	else
	{
		pView->m_strSex += _T("여자");
	}
	pView->m_strHobby = _T("내가 선택한 취미 : ");
	if (m_bChecked[0])
	{
		pView->m_strHobby += _T("독서 ");
	}
	if (m_bChecked[1])
	{
		pView->m_strHobby += _T("낚시 ");
	}
	if (m_bChecked[2])
	{
		pView->m_strHobby += _T("운동 ");
	}
	pView->Invalidate();
}
