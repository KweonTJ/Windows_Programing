﻿#pragma once
#include "CSearchCtrl.h"


// CSearchPane

class CSearchPane : public CDockablePane
{
	DECLARE_DYNAMIC(CSearchPane)

public:
	CSearchPane();
	virtual ~CSearchPane();

protected:
	DECLARE_MESSAGE_MAP()
public:
	CSearchCtrl m_ctrlSearch;
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
};


