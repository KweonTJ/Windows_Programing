﻿
// AssignmentView.cpp: CAssignmentView 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "Assignment.h"
#endif

#include "AssignmentDoc.h"
#include "AssignmentView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAssignmentView

IMPLEMENT_DYNCREATE(CAssignmentView, CView)

BEGIN_MESSAGE_MAP(CAssignmentView, CView)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
END_MESSAGE_MAP()

// CAssignmentView 생성/소멸

CAssignmentView::CAssignmentView() noexcept
{
	// TODO: 여기에 생성 코드를 추가합니다.

}

CAssignmentView::~CAssignmentView()
{
}

BOOL CAssignmentView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CView::PreCreateWindow(cs);
}

// CAssignmentView 그리기

void CAssignmentView::OnDraw(CDC* pDC)
{
	CAssignmentDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: 여기에 원시 데이터에 대한 그리기 코드를 추가합니다.
	pDC->TextOut(20, 20, _T("다음의 조건으로 검색합니다."));
	pDC->TextOut(20, 50, m_strTarget);
	pDC->TextOut(20, 80, m_strFileType);
	pDC->TextOut(20, 110, m_strDrive);
	pDC->TextOut(20, 140, m_strName);

}

void CAssignmentView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CAssignmentView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CAssignmentView 진단

#ifdef _DEBUG
void CAssignmentView::AssertValid() const
{
	CView::AssertValid();
}

void CAssignmentView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CAssignmentDoc* CAssignmentView::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CAssignmentDoc)));
	return (CAssignmentDoc*)m_pDocument;
}
#endif //_DEBUG


// CAssignmentView 메시지 처리기
