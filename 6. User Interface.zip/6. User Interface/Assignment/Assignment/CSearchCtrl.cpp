﻿// CSearchCtrl.cpp: 구현 파일
//

#include "pch.h"
#include "Assignment.h"
#include "afxdialogex.h"
#include "CSearchCtrl.h"
#include "MainFrm.h"
#include "AssignmentDoc.h"
#include "AssignmentView.h"


// CSearchCtrl 대화 상자

IMPLEMENT_DYNAMIC(CSearchCtrl, CDialogEx)

CSearchCtrl::CSearchCtrl(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG1, pParent)
	, m_strName(_T(""))
{
	m_bTarget = true;
	m_bChecked[0] = m_bChecked[1] = m_bChecked[2] = false;
}

CSearchCtrl::~CSearchCtrl()
{
}

void CSearchCtrl::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_DRIVE, m_cbDrive);
	DDX_Text(pDX, IDC_EDIT_NAME, m_strName);
}


BEGIN_MESSAGE_MAP(CSearchCtrl, CDialogEx)
	ON_COMMAND(IDC_RADIO_FILE, &CSearchCtrl::OnRadioFile)
	ON_COMMAND(IDC_RADIO_FOLDER, &CSearchCtrl::OnRadioFolder)
	ON_BN_CLICKED(IDC_CHECK_MFC, &CSearchCtrl::OnClickedCheckMfc)
	ON_BN_CLICKED(IDC_CHECK_MULTI, &CSearchCtrl::OnClickedCheckMulti)
	ON_BN_CLICKED(IDC_CHECK_WORD, &CSearchCtrl::OnClickedCheckWord)
	ON_BN_CLICKED(IDC_BUTTON_SEARCH, &CSearchCtrl::OnClickedButtonSearch)
	ON_BN_CLICKED(IDC_BUTTON_NEW, &CSearchCtrl::OnClickedButtonNew)
END_MESSAGE_MAP()


// CSearchCtrl 메시지 처리기

BOOL CSearchCtrl::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	((CButton*)GetDlgItem(IDC_RADIO_FILE))->SetCheck(TRUE);

	m_cbDrive.SetCurSel(0);
	m_cbDrive.AddString(_T("하드 드라이브 C:"));
	m_cbDrive.AddString(_T("하드 드라이브 D:"));
	m_cbDrive.AddString(_T("하드 드라이브 [C:, D:]"));

	// TODO:  여기에 추가 초기화 작업을 추가합니다.

	return TRUE;  // return TRUE unless you set the focus to a control
	// 예외: OCX 속성 페이지는 FALSE를 반환해야 합니다.
}

void CSearchCtrl::OnRadioFile()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	m_bTarget = true;
	((CButton*)GetDlgItem(IDC_CHECK_MFC))->EnableWindow(TRUE);
	((CButton*)GetDlgItem(IDC_CHECK_MULTI))->EnableWindow(TRUE);
	((CButton*)GetDlgItem(IDC_CHECK_WORD))->EnableWindow(TRUE);
}

void CSearchCtrl::OnRadioFolder()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	m_bTarget = false;
	((CButton*)GetDlgItem(IDC_CHECK_MFC))->EnableWindow(FALSE);
	((CButton*)GetDlgItem(IDC_CHECK_MULTI))->EnableWindow(FALSE);
	((CButton*)GetDlgItem(IDC_CHECK_WORD))->EnableWindow(FALSE);
}

void CSearchCtrl::OnClickedCheckMfc()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	if (!m_bChecked[0])
	{
		((CButton*)GetDlgItem(IDC_CHECK_MFC))->SetCheck(TRUE);
	}
	else
	{
		((CButton*)GetDlgItem(IDC_CHECK_MFC))->SetCheck(FALSE);
	}
	m_bChecked[0] = !m_bChecked[0];
}

void CSearchCtrl::OnClickedCheckMulti()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	if (!m_bChecked[1])
	{
		((CButton*)GetDlgItem(IDC_CHECK_MULTI))->SetCheck(TRUE);
	}
	else
	{
		((CButton*)GetDlgItem(IDC_CHECK_MULTI))->SetCheck(FALSE);
	}
	m_bChecked[1] = !m_bChecked[1];
}

void CSearchCtrl::OnClickedCheckWord()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	if (!m_bChecked[2])
	{
		((CButton*)GetDlgItem(IDC_CHECK_WORD))->SetCheck(TRUE);
	}
	else
	{
		((CButton*)GetDlgItem(IDC_CHECK_WORD))->SetCheck(FALSE);
	}
	m_bChecked[2] = !m_bChecked[2];
}

void CSearchCtrl::OnClickedButtonSearch()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CAssignmentView* pView = (CAssignmentView*)pFrame->GetActiveView();
	UpdateData(TRUE);

	pView->m_strTarget = _T("검색 대상 : ");
	if (m_bTarget)
	{
		pView->m_strTarget += _T("파일");
	}
	else
	{
		pView->m_strTarget += _T("폴더");
	}

	pView->m_strFileType = _T("검색 파일 종류 : ");
	if (m_bChecked[0])
	{
		pView->m_strFileType += _T("Visual C++ 프로젝트 파일 ");
	}
	if (m_bChecked[1])
	{
		pView->m_strFileType += _T("멀티미디어 파일 ");
	}
	if (m_bChecked[2])
	{
		pView->m_strFileType += _T("문서 파일 ");
	}

	pView->m_strDrive = _T("검색 위치 : ");
	int nIndex = m_cbDrive.GetCurSel();
	if (nIndex == CB_ERR)
	{
		return;
	}
	CString strSelectedText;
	m_cbDrive.GetLBText(nIndex, strSelectedText);
	pView->m_strDrive += strSelectedText;

	pView->m_strName = _T("이름 : ");
	pView->m_strName += m_strName;

	pView->Invalidate();
}

void CSearchCtrl::OnClickedButtonNew()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CAssignmentView* pView = (CAssignmentView*)pFrame->GetActiveView();
	UpdateData(TRUE);

	m_bTarget = true;

	if (m_bChecked[0])
		((CButton*)GetDlgItem(IDC_CHECK_MFC))->SetCheck(FALSE);
	if (m_bChecked[1])
		((CButton*)GetDlgItem(IDC_CHECK_MULTI))->SetCheck(FALSE);
	if (m_bChecked[2])
		((CButton*)GetDlgItem(IDC_CHECK_WORD))->SetCheck(FALSE);

	m_bChecked[0] = m_bChecked[1] = m_bChecked[2] = false;

	m_cbDrive.SetCurSel(0);

	m_strName = _T("");

	pView->m_strDrive = _T("");
	pView->m_strFileType = _T("");
	pView->m_strName = _T("");
	pView->m_strTarget = _T("");

	pView->Invalidate();
}
