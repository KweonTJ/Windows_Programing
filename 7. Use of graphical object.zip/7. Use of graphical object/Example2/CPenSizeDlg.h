﻿#pragma once
#include "afxdialogex.h"


// CPenSizeDlg 대화 상자

class CPenSizeDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CPenSizeDlg)

public:
	CPenSizeDlg(CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~CPenSizeDlg();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG_PEN };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	DECLARE_MESSAGE_MAP()
public:
	UINT m_nPenSize;
	CSpinButtonCtrl m_spinPen;
	virtual BOOL OnInitDialog();
};
