﻿
// AssignmentView.cpp: CAssignmentView 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "Assignment.h"
#endif

#include "AssignmentDoc.h"
#include "AssignmentView.h"
#include "math.h"
#include "MainFrm.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAssignmentView

IMPLEMENT_DYNCREATE(CAssignmentView, CView)

BEGIN_MESSAGE_MAP(CAssignmentView, CView)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_PAINT()
	ON_COMMAND(ID_RECTANGLE, &CAssignmentView::OnRectangle)
	ON_COMMAND(ID_CIRCLE, &CAssignmentView::OnCircle)
	ON_COMMAND(ID_INCREASE, &CAssignmentView::OnIncrease)
	ON_COMMAND(ID_DECREASE, &CAssignmentView::OnDecrease)
	ON_WM_PAINT()
	ON_WM_UPDATEUISTATE()
END_MESSAGE_MAP()

// CAssignmentView 생성/소멸

CAssignmentView::CAssignmentView() noexcept
{
	m_nDrawDown = RECTANGLE_MODE;

	m_bLButtonDown = false;

	m_nResolution = 64;

	m_ptStart.SetPoint(0, 0);
	m_ptPrev.SetPoint(0, 0);

	m_rtRect.SetRectEmpty();
}

CAssignmentView::~CAssignmentView()
{
}

BOOL CAssignmentView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CView::PreCreateWindow(cs);
}

// CAssignmentView 그리기

void CAssignmentView::OnDraw(CDC* pDC)
{
	CAssignmentDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: 여기에 원시 데이터에 대한 그리기 코드를 추가합니다.
}

void CAssignmentView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CAssignmentView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CAssignmentView 진단

#ifdef _DEBUG
void CAssignmentView::AssertValid() const
{
	CView::AssertValid();
}

void CAssignmentView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CAssignmentDoc* CAssignmentView::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CAssignmentDoc)));
	return (CAssignmentDoc*)m_pDocument;
}
#endif //_DEBUG


// CAssignmentView 메시지 처리기

void CAssignmentView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	switch (m_nDrawDown)
	{
	case RECTANGLE_MODE:
		m_rtRect = CRect(0, 0, 0, 0);
		m_ptStart = point;
		m_ptPrev = point;
		m_bLButtonDown = true;
		break;
	case CIRCLE_MODE:
		m_ptStart = m_ptPrev = point;
		m_bLButtonDown = true;
		for (int i = 0; i < 1025; i++)
			m_ptEllipse[i] = CPoint(0, 0);
		Invalidate(TRUE);
		break;
	default:
		break;
	}

	RECT rectClient;// 구조체 변수 선언
	SetCapture();// 마우스 캡처
	GetClientRect(&rectClient);// 클라이언트 영역 받음
	ClientToScreen(&rectClient);// 스크린 좌표계 변환
	::ClipCursor(&rectClient);// 마우스 이동범위를 클라이언트 영역으로 제한

	CView::OnLButtonDown(nFlags, point);
}

void CAssignmentView::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	switch (m_nDrawDown)
	{
	case RECTANGLE_MODE:
		if (m_bLButtonDown)
		{
			m_bLButtonDown = false;
			m_rtRect = CRect(m_ptStart.x, m_ptStart.y, point.x, point.y);
		}
		break;
	case CIRCLE_MODE:
		if (m_bLButtonDown)
		{
			m_bLButtonDown = false;
		}
		break;
	}

	ReleaseCapture();
	::ClipCursor(NULL);
	Invalidate();

	CView::OnLButtonUp(nFlags, point);
}

void CAssignmentView::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	CClientDC dc(this); // 클라이언트 객체 얻음
	CPen pen, * oldpen;
	pen.CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
	// pen 객체 생성
	oldpen = dc.SelectObject(&pen); // pen 객체 등록
	dc.SetROP2(R2_NOTXORPEN); // R2_NOTXORPEN으로 설정

	switch (m_nDrawDown)
	{
	case RECTANGLE_MODE:
		if (m_bLButtonDown)
		{
			dc.Rectangle(m_ptStart.x, m_ptStart.y, m_ptPrev.x, m_ptPrev.y);
			dc.Rectangle(m_ptStart.x, m_ptStart.y, point.x, point.y);
			m_ptPrev = point;
		}
		break;
	case CIRCLE_MODE:
		if (m_bLButtonDown)
		{
			dc.IntersectClipRect(m_rtRect);
			ComputeCircle();
			dc.MoveTo(m_ptEllipse[0]);
			for (int i = 0; i < m_nResolution; i++)
			{
				dc.LineTo(m_ptEllipse[i]);
			}
			dc.LineTo(m_ptEllipse[0]);

			m_ptPrev = point;
			ComputeCircle();
			dc.MoveTo(m_ptEllipse[0]);
			for (int i = 0; i < m_nResolution; i++)
			{
				dc.LineTo(m_ptEllipse[i]);
			}
			dc.LineTo(m_ptEllipse[0]);
			break;
		}
	}
	dc.SelectObject(oldpen); // 이전 pen으로 설정
	pen.DeleteObject(); // pen 객체 삭제

	CView::OnMouseMove(nFlags, point);
}


void CAssignmentView::OnRectangle()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	m_nDrawDown = RECTANGLE_MODE;
}

void CAssignmentView::OnCircle()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	m_nDrawDown = CIRCLE_MODE;
}

void CAssignmentView::OnIncrease()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	if (m_nResolution >= 1024)
	{
		AfxMessageBox(_T("최대 해상도에 도달했습니다."));
	}
	else
	{
		m_nResolution *= 2;

		UpdateStatusBarText();
	}
}

void CAssignmentView::OnDecrease()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	if (m_nResolution <= 2)
	{
		AfxMessageBox(_T("최소 해상도에 도달했습니다."));
	}
	else
	{
		m_nResolution /= 2;

		UpdateStatusBarText();
	}
}

void CAssignmentView::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: 여기에 메시지 처리기 코드를 추가합니다.
	dc.Rectangle(m_rtRect);

	dc.IntersectClipRect(m_rtRect);

	if (m_ptEllipse[0] != CPoint(0, 0))
	{
		dc.MoveTo(m_ptEllipse[0]);
		for (int i = 0; i < m_nResolution; i++)
		{
			dc.LineTo(m_ptEllipse[i]);
		}
		dc.LineTo(m_ptEllipse[0]);
	}
	// 그리기 메시지에 대해서는 CView::OnPaint()을(를) 호출하지 마십시오.
}

void CAssignmentView::ComputeCircle()
{
	// TODO: 여기에 구현 코드 추가.
	double x, y, r, radian;

	// 반지름 r 계산
	r = sqrt((double)((m_ptStart.x - m_ptPrev.x) * (m_ptStart.x - m_ptPrev.x) +
		(m_ptStart.y - m_ptPrev.y) * (m_ptStart.y - m_ptPrev.y)));

	// radian(라디안) = M_PI * (360/해상도)/180
	radian = M_PI * 2 / (double)m_nResolution;

	//해상도에 따른 원의 좌표
	for (int i = 0; i < m_nResolution; i++)
	{
		x = m_ptStart.x + r * cos(radian * i);
		y = m_ptStart.y + r * sin(radian * i);
		m_ptEllipse[i] = CPoint((int)x, (int)y);
	}
}

//void CAssignmentView::UpdateStatusBarText()
//{
//	// TODO: 여기에 구현 코드 추가.
//	CMainFrame* pMainFrame = (CMainFrame*)AfxGetMainWnd();
//	if (pMainFrame == nullptr) return;
//
//	CString strRes;
//	strRes.Format(_T("해상도 %d"), m_nResolution);
//
//	int nIndex = pMainFrame->m_wndStatusBar.CommandToIndex(ID_INDICATOR_RESOLUTION);
//
//	pMainFrame->m_wndStatusBar.SetPaneText(nIndex, strRes);
//}

void CAssignmentView::UpdateStatusBarText()
{
	auto* frame = static_cast<CMainFrame*>(AfxGetMainWnd());
	if (!frame) return;

	CString s;  s.Format(_T("해상도 %d"), m_nResolution);
	int idx = frame->m_wndStatusBar.CommandToIndex(ID_INDICATOR_RESOLUTION);
	if (idx >= 0) frame->m_wndStatusBar.SetPaneText(idx, s);
}
