﻿
// Assignment3View.cpp: CAssignment3View 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "Assignment3.h"
#endif

#include "Assignment3Doc.h"
#include "Assignment3View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CAssignment3View

IMPLEMENT_DYNCREATE(CAssignment3View, CView)

BEGIN_MESSAGE_MAP(CAssignment3View, CView)
	ON_WM_CREATE()
	ON_WM_TIMER()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_WM_DESTROY()
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()

// CAssignment3View 생성/소멸

CAssignment3View::CAssignment3View() noexcept
	: m_nMinute(0)
	, m_nSecond(0)
	, m_nMSec(0)
	, m_nCount(0)
	, m_bStopWatchRun(false)
	, m_bTimerRun(false)
	, m_bTimerType(false)
{
	// TODO: 여기에 생성 코드를 추가합니다.
	for (int i = 0; i < 30; i++)
	{
		m_strRecord[i] = _T("");
	}
	m_strStopWatch = _T("00:00.00");
}

CAssignment3View::~CAssignment3View()
{
}

BOOL CAssignment3View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CView::PreCreateWindow(cs);
}

// CAssignment3View 그리기

void CAssignment3View::OnDraw(CDC* pDC)
{
	CAssignment3Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: 여기에 원시 데이터에 대한 그리기 코드를 추가합니다.
	CRect rect;
	GetClientRect(&rect);
	pDC->DrawText(m_strStopWatch, rect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);

	int x = 10; // 시작 X 좌표
	int y = 50; // 시작 Y 좌표 (스톱워치 아래)
	for (int i = 0; i < m_nCount; i++)
	{
		pDC->TextOut(x, y, m_strRecord[i]);
		x += pDC->GetTextExtent(m_strRecord[i]).cx + 20; // 가로 간격
	}
}


// CAssignment3View 진단

#ifdef _DEBUG
void CAssignment3View::AssertValid() const
{
	CView::AssertValid();
}

void CAssignment3View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CAssignment3Doc* CAssignment3View::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CAssignment3Doc)));
	return (CAssignment3Doc*)m_pDocument;
}
#endif //_DEBUG


// CAssignment3View 메시지 처리기

int CAssignment3View::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  여기에 특수화된 작성 코드를 추가합니다.
	SetTimer(0, 10, NULL);
	m_bTimerRun = TRUE;
	return 0;
}

void CAssignment3View::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	m_nMSec++;
	if (m_nMSec == 60)
	{
		m_nMSec = 0;
		m_nSecond++;
	}
	if (m_nSecond == 60)
	{
		m_nSecond = 0;
		m_nMinute++;
	}
	m_strStopWatch.Format(_T("%02d: %02d. %02d"), m_nMinute, m_nSecond, m_nMSec);

	Invalidate();
	CView::OnTimer(nIDEvent);
}

void CAssignment3View::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	if (m_bStopWatchRun==false)
	{
		m_bStopWatchRun = true;
		SetTimer(0, 10, NULL);
	}
	else if (m_bStopWatchRun==true)
	{
		m_bStopWatchRun = false;
		KillTimer(0);
	}
	CView::OnLButtonDown(nFlags, point);
}


void CAssignment3View::OnRButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	if (m_bStopWatchRun == false)
	{
		if (AfxMessageBox(_T("스톱워치를 초기화하시겠습니까?"),
			MB_YESNO | MB_ICONQUESTION) == IDYES)
		{
			//모든 변수를 초기화
			for (int i = 0; i < 30; i++) 
			{
				m_strRecord[i].Empty();
			}

			m_nCount = 0;
			m_nMinute = 0;
			m_nSecond = 0;
			m_nMSec = 0;
			m_strStopWatch = _T("00:00.00");
		}
		Invalidate();
	}
	else
	{
		AfxMessageBox(_T("작동 중에는 초기화 할 수 없습니다."),
			IDOK | MB_ICONERROR);
	}
	CView::OnRButtonDown(nFlags, point);
}

void CAssignment3View::OnDestroy()
{
	CView::OnDestroy();

	// TODO: 여기에 메시지 처리기 코드를 추가합니다.
	if (m_bTimerRun)
		KillTimer(0);
}

void CAssignment3View::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// 스톱워치 실행 중이고, 스페이스바를 처음 눌렀을 때만 처리
	if (m_bStopWatchRun && nChar == VK_SPACE && nRepCnt == 1)
	{
		// 10개 이상이면 기존 기록 모두 삭제
		if (m_nCount >= 10)
		{
			for (int i = 0; i < 30; i++)
				m_strRecord[i].Empty();
			m_nCount = 0;
		}

		// 현재 스톱워치 기록 저장
		CString strRecord;
		strRecord.Format(L"%2d. ", m_nCount + 1);
		m_strRecord[m_nCount] = strRecord + m_strStopWatch;

		m_nCount++; // 한 번만 증가
	}

	Invalidate();
	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}
