﻿
// Assignment3View.h: CAssignment3View 클래스의 인터페이스
//

#pragma once


class CAssignment3View : public CView
{
protected: // serialization에서만 만들어집니다.
	CAssignment3View() noexcept;
	DECLARE_DYNCREATE(CAssignment3View)

// 특성입니다.
public:
	CAssignment3Doc* GetDocument() const;

// 작업입니다.
public:

// 재정의입니다.
public:
	virtual void OnDraw(CDC* pDC);  // 이 뷰를 그리기 위해 재정의되었습니다.
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:

// 구현입니다.
public:
	virtual ~CAssignment3View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 생성된 메시지 맵 함수
protected:
	DECLARE_MESSAGE_MAP()
public:
	bool m_bTimerRun;
	bool m_bTimerType;
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	CString m_strTimer;
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnDestroy();
	CString m_strStopWatch;
	CString m_strRecord[30];
	int m_nCount;
	int m_nMinute;
	int m_nSecond;
	int m_nMSec;
	bool m_bStopWatchRun;
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
};

#ifndef _DEBUG  // Assignment3View.cpp의 디버그 버전
inline CAssignment3Doc* CAssignment3View::GetDocument() const
   { return reinterpret_cast<CAssignment3Doc*>(m_pDocument); }
#endif

